from ultralytics import YOLO
import os

# 定义模型列表（可以根据需要调整）
models = [
    "yolo11n", 
    "smallob", 
    "HSFPN+smallob", 
    "DWR+smallob", 
    "HSFPN+DWR+smallob", 
]

# 定义图像文件夹路径
source = "ASS1/images/val"

# 定义保存路径的基础目录
base_save_dir = "runs/predict/ASS1"
#base_save_dir = "runs/boxx"
# 循环处理每个模型
for model_name in models:
    # 加载对应的权重文件
    weights_path = f"runs/ASS1/{model_name}/weights/best.pt"
    model = YOLO(weights_path)

    # 创建模型名称的保存目录
    save_dir = os.path.join(base_save_dir, model_name)
    os.makedirs(save_dir, exist_ok=True)

    # 运行推理并保存结果
    results = model(source, save=True, save_dir=save_dir)

    print(f"Results for {model_name} saved to {save_dir}")
